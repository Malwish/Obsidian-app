La división es la operación inversa al producto, en fracciones podemos invertir el divisor (Véase [[División o cociente]]) y resolver como producto, ya que son análogas.

Si tenemos 3/5 : 3/4 podemos en vez de eso multiplicar 3/5 x 4/3. 12/15.