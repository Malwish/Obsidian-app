Para dividir dos números que sean decimales, lo que podemos hacer para facilitar el trabajo gracias a la propiedad de conmutatividad del producto es lo siguiente.

Imagina que tienes la siguiente división.  5/3. Esta división es la misma que (5x10)/(3x10)
ya que podemos realizar 5/3 x10/10 y el resultado sería lo mismo por el hecho de que 10/10 es 1.

Esto nos permite multiplicar por 10 cada una de las unidades tanto como queramos, por lo que si tuviéramos una división de 0.001 : 0.0002 podemos multiplicar x10000 a ambos lados de la división y facilitar mucho el procedimiento quedando solo 10/2. 
