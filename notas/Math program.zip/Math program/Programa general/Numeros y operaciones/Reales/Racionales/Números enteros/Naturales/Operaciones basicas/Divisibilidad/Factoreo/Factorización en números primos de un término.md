
Sea cual sea el número podemos escribirlo como un producto de [[Números primos]].

140 :    (2.2.5.7)
4458: (2.3.743) siendo 743 primo